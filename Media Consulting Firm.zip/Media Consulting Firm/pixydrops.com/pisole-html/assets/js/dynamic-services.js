const serviceData = {
    'service-strategic-communication': {
        title: 'Strategic Communication & Media Consulting',
        description: `We craft clear, impactful communication strategies that amplify your message and drive results. Our expertise ensures that your brand connects with the right audience, using the right approach, at the right time.

- Campaign strategy design and execution – Tailored plans that deliver measurable impact.

- Stakeholder engagement – Building strong relationships that foster trust and collaboration.

- Advocacy communication – Creating persuasive narratives that inspire action and change.`
    },
    'service-content-development': {
        title: 'Content Development & Publishing',
        description: `We transform ideas into compelling content that informs, persuades, and inspires. From print to broadcast, our work ensures your message is heard, remembered, and acted upon.

- Magazine & journal production – End-to-end publishing of impactful titles such as Safe Wheel Nigeria Magazine and Renewed Hope Diary Magazine.

- Speechwriting, reports, and policy briefs – Clear, persuasive writing that shapes narratives and drives decision-making.

- Script development – Engaging scripts for radio, TV, and documentaries that bring stories to life.`
    },
    'service-public-enlightenment': {
        title: 'Public Enlightenment & Social Reorientation',
        description: `We deliver campaigns that inform, educate, and transform communities.

- Grassroots awareness – Mobilizing citizens through local engagement.

- Education programs – Road safety, health, and civic responsibility initiatives.

- Behavioral change communication (BCC) – Tools and strategies that shift mindsets.`
    },
    'service-film-creation': {
        title: 'Film Creation & Creative Storytelling',
        description: `We harness the power of film to inspire, educate, and advocate for positive change.

- Content creation – Movies, docudramas, and short films that spark conversations.

- Story development – Narratives that drive social reorientation and advocacy.

- Production support – End-to-end assistance with filming, editing, and promotional campaigns.`
    },
    'service-digital-media': {
        title: 'Digital Media & Creative Production',
        description: `We create digital experiences that captivate audiences and build lasting impressions.

- Online management – Websites and social media platforms tailored for impact.

- Audio-visual content – Documentaries, jingles, animations, and more.

- Brand identity – Graphics, logos, and designs that elevate your presence.`
    },
    'service-events-publicity': {
        title: 'Events, Publicity & Government Engagement',
        description: `We design and manage high-impact events that shape narratives and strengthen visibility.

- Public sector promotion – Showcasing government programs and initiatives.

- Campaign launches – Flagship events that capture national attention.

- Stakeholder forums – Workshops, roundtables, and full media coverage management.`
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const serviceItems = document.querySelectorAll('.widget-categories ul li');
    const serviceDescriptionArea = document.getElementById('service-description-area');

    serviceItems.forEach(item => {
        item.addEventListener('click', function(event) {
            event.preventDefault();
            const serviceId = this.id;
            const data = serviceData[serviceId];

            if (data) {
                serviceDescriptionArea.innerHTML = `
                    <h3>${data.title}</h3>
                    <p class="mt-4 mb-4">${data.description.replace(/\n/g, '<br>')}</p>
                `;
            } else {
                serviceDescriptionArea.innerHTML = `
                    <h3>Service Not Found</h3>
                    <p class="mt-4 mb-4">The description for this service is not available.</p>
                `;
            }
        });
    });
});
